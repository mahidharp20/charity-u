 // Retrieve data from localStorage
 const volunteerData = JSON.parse(localStorage.getItem('volunteerData'));

 // If data exists, display it
 if (volunteerData) {
     document.getElementById('firstName').textContent = volunteerData.firstName;
     document.getElementById('lastName').textContent = volunteerData.lastName;
     document.getElementById('email').textContent = volunteerData.email;
     document.getElementById('mobileNumber').textContent = volunteerData.mobileNumber;
     document.getElementById('skills').textContent = volunteerData.skills;
     document.getElementById('availability').textContent = volunteerData.availability;
 } else {
     alert("No volunteer data found!");
 }
