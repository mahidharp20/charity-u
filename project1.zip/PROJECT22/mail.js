function sendOTP() {
    const email = document.getElementById("email");
    const otpverify = document.getElementsByClassName("otpverify")[0];

    // Generate a random 4-digit OTP
    let otp_val = Math.floor(1000 + Math.random() * 9000);

    let emailBody = `<h2>Your OTP is: ${otp_val}</h2>`;

    Email.send({
        SecureToken: "969B1756A197DDF285F926A7F6581E82CE9A", // Replace with your actual secure token
        To: email.value,
        From: "charityorg@gmail.com", // Replace with a valid sender email
        Subject: "Your OTP for Verification",
        Body: emailBody,
    }).then((message) => {
        if (message === "OK") {
            alert("OTP sent to your email: " + email.value);

            // Show the OTP verification fields
            otpverify.style.display = "flex";

            const otp_inp = document.getElementById("otp_inp");
            const otp_btn = document.getElementById("otp_btn");

            otp_btn.addEventListener("click", () => {
                if (otp_inp.value == otp_val) {
                    alert("Email Address Verified!");
                } else {
                    alert("Invalid OTP. Please try again.");
                }
            });
        } else {
            alert("Failed to send OTP. Please check your email address and try again.");
        }
    });
}
