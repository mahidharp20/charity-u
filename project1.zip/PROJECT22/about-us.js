// Open the donation modal
function openDonationModal() {
    document.getElementById('donation-modal').style.display = 'flex';
  }
  
  // Close the donation modal
  function closeModal() {
    document.getElementById('donation-modal').style.display = 'none';
  }
  
  // Handle donation form submission
  document.getElementById('donation-form').addEventListener('submit', async function (e) {
    e.preventDefault();
  
    const donationDetails = {
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value,
      amount: document.getElementById('amount').value,
    };
  
    try {
      const response = await fetch('http://localhost:5000/donate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(donationDetails),
      });
  
      if (response.ok) {
        alert('Thank you for your donation!');
        closeModal();
      } else {
        alert('Failed to process your donation.');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Please try again.');
    }
  });
  