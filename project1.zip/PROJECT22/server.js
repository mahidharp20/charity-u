const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const path = require('path');

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB Connection
const MONGO_URI = 'mongodb://127.0.0.1:27017/Login-tut'; // Adjust as needed
mongoose.connect(MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => console.log('Connected to MongoDB successfully!'))
    .catch((error) => {
        console.error('Error connecting to MongoDB:', error.message);
        process.exit(1);
    });

// **Schemas and Models**
const donationSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: String, required: true },
    address: { type: String, required: true },
    amount: { type: Number, required: true, min: 1 },
    message: { type: String },
}, { collection: 'donations' });

const Donation = mongoose.model('Donation', donationSchema);

const userSchema = new mongoose.Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
}, { collection: 'users' });

const User = mongoose.model('User', userSchema);

const feedbackSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    message: { type: String, required: true },
}, { collection: 'feedback' });

const Feedback = mongoose.model('Feedback', feedbackSchema);

const volunteerSchema = new mongoose.Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    mobileNumber: { type: String, required: true },
    skills: { type: String, required: true },
    availability: { type: Number, required: true },
}, { collection: 'volunteers' });

const Volunteer = mongoose.model('Volunteer', volunteerSchema);

// **Routes**
app.post('/volunteer', async (req, res) => {
    const { firstName, lastName, email, mobileNumber, skills, availability } = req.body;

    if (!firstName || !lastName || !email || !mobileNumber || !skills || !availability) {
        return res.status(400).send({ error: 'All fields are required.' });
    }

    try {
        const newVolunteer = new Volunteer({ firstName, lastName, email, mobileNumber, skills, availability });
        await newVolunteer.save();
        res.status(201).send({ message: 'Successfully registered as a volunteer!' });
    } catch (error) {
        console.error('Error saving volunteer:', error.message);
        if (error.code === 11000) {
            res.status(400).send({ error: 'Email already registered.' });
        } else {
            res.status(500).send({ error: 'Failed to register as a volunteer.' });
        }
    }
});

app.post('/donate', async (req, res) => {
    const { name, email, phone, address, amount, message } = req.body;

    if (!name || !email || !phone || !address || !amount) {
        return res.status(400).send({ error: 'All fields are required.' });
    }

    try {
        const donation = new Donation({ name, email, phone, address, amount, message });
        await donation.save();
        res.status(201).send({ message: 'Donation saved successfully!' });
    } catch (error) {
        console.error('Error saving donation:', error.message);
        res.status(500).send({ error: 'Failed to save donation.' });
    }
});

app.post('/signup', async (req, res) => {
    const { firstName, lastName, email, password } = req.body;

    if (!firstName || !lastName || !email || !password) {
        return res.status(400).send({ error: 'All fields are required.' });
    }

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).send({ error: 'Email already registered.' });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const newUser = new User({ firstName, lastName, email, password: hashedPassword });
        await newUser.save();
        res.status(201).send({ message: 'Signup successful!' });
    } catch (error) {
        console.error('Error in /signup:', error.message);
        res.status(500).send({ error: 'Failed to sign up.' });
    }
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).send({ error: 'Both email and password are required.' });
    }

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).send({ error: 'User not found.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).send({ error: 'Invalid credentials.' });
        }

        res.status(200).send({ message: 'Login successful!', user });
    } catch (error) {
        console.error('Error in /login:', error.message);
        res.status(500).send({ error: 'Error logging in.' });
    }
});

app.post('/feedback', async (req, res) => {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
        return res.status(400).send({ error: 'All fields are required.' });
    }

    try {
        const feedback = new Feedback({ name, email, message });
        await feedback.save();
        res.status(201).send({ message: 'Feedback submitted successfully!' });
    } catch (error) {
        console.error('Error in /feedback:', error.message);
        res.status(500).send({ error: 'Failed to submit feedback.' });
    }
});

// Start the server
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
