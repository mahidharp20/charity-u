
document.addEventListener("DOMContentLoaded", () => {
    const user = JSON.parse(localStorage.getItem('currentUser'));

    if (!user) {
        alert("Please log in first.");
        window.location.href = 'index1.html';
        return;
    }

    document.getElementById('user-firstName').textContent = user.firstName;
    document.getElementById('user-lastName').textContent = user.lastName;
    document.getElementById('user-email').textContent = user.email;

    document.getElementById('logout-btn').addEventListener('click', () => {
        localStorage.removeItem('currentUser');
        alert("You have been logged out.");
        window.location.href = 'index1.html';
    });
});
