// Handle feedback form submission
document.getElementById('feedback-form').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent the default form submission

    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();

    // Validation checks
    if (name === '' || email === '' || message === '') {
        alert('All fields are required. Please fill in the form completely.');
        return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    try {
        // Send data to the server
        const response = await fetch('http://localhost:5000/feedback', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, email, message }),
        });

        if (response.ok) {
            alert('Feedback submitted successfully!');
            document.getElementById('feedback-form').reset(); // Reset form fields
        } else {
            const { error } = await response.json();
            alert(`Error: ${error || 'Failed to submit feedback'}`);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while submitting your feedback.');
    }
});
