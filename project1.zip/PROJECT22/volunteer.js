document.getElementById('volunteerForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // Capture form data
    const formData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        email: document.getElementById('email').value,
        mobileNumber: document.getElementById('mobileNumber').value,
        skills: document.getElementById('skills').value,
        availability: document.getElementById('availability').value,
    };

    // Send data to the backend using fetch
    fetch('http://localhost:5000/volunteer', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData), // Send form data as JSON
    })
    .then(response => response.json())
    .then(result => {
        if (result.message) {
            alert(result.message);
            window.location.href = 'volunteer.index.html';
        } else {
            alert(result.error || 'Failed to register as a volunteer.');
        }
    })
    .catch(error => {
        alert('Login Successfull.');
        console.error('Error:', error);
    });
});