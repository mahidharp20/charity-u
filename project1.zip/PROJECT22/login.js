document.addEventListener('DOMContentLoaded', () => {
    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    const signupForm = document.getElementById('signup-form');
    const loginForm = document.getElementById('login-form');
    const forgotPasswordForm = document.getElementById('forgot-password-form');
    const emailStep = document.getElementById('email-step');
    const verifyStep = document.getElementById('verify-step');
    const resetStep = document.getElementById('reset-step');

    document.getElementById('signup-btn').addEventListener('click', async () => {
        const firstName = document.getElementById('signup-firstName').value.trim();
        const lastName = document.getElementById('signup-lastName').value.trim();
        const email = document.getElementById('signup-email').value.trim();
        const password = document.getElementById('signup-password').value.trim();

        if (!firstName || !lastName || !email || !password) {
            alert('All fields are required for Signup!');
            return;
        }

        if (!validateEmail(email)) {
            alert('Please enter a valid email address!');
            return;
        }

        if (password.length < 6) {
            alert('Password must be at least 6 characters long!');
            return;
        }

        try {
            const response = await fetch('http://localhost:5000/signup', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firstName, lastName, email, password }),
            });

            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                signupForm.classList.add('hidden');
                loginForm.classList.remove('hidden');
            } else {
                alert(data.error || 'Signup failed. Please try again.');
            }
        } catch (error) {
            console.error('Signup error:', error);
            alert('An error occurred. Please try again later.');
        }
    });

    document.getElementById('login-btn').addEventListener('click', async () => {
        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('login-password').value.trim();

        if (!email || !password) {
            alert('All fields are required for Login!');
            return;
        }

        if (!validateEmail(email)) {
            alert('Please enter a valid email address!');
            return;
        }

        try {
            const response = await fetch('http://localhost:5000/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
            });

            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                window.location.href = 'index.html';
            } else {
                alert(data.error || 'Invalid credentials. Please try again.');
            }
        } catch (error) {
            console.error('Login error:', error);
            alert('An error occurred. Please try again later.');
        }
    });

    document.getElementById('forgot-password-link').addEventListener('click', (e) => {
        e.preventDefault();
        loginForm.classList.add('hidden');
        forgotPasswordForm.classList.remove('hidden');
    });

    document.getElementById('show-login-from-forgot').addEventListener('click', (e) => {
        e.preventDefault();
        forgotPasswordForm.classList.add('hidden');
        loginForm.classList.remove('hidden');
    });

    document.getElementById('send-code-btn').addEventListener('click', async () => {
        const email = document.getElementById('forgot-email').value.trim();
        if (!validateEmail(email)) {
            alert('Please enter a valid email.');
            return;
        }

        try {
            const response = await fetch('http://localhost:5000/forgot-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email }),
            });
            const data = await response.json();
            if (response.ok) {
                alert('Verification code sent to your email.');
                emailStep.classList.add('hidden');
                verifyStep.classList.remove('hidden');
            } else {
                alert(data.error || 'Failed to send verification code.');
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred.');
        }
    });

    document.getElementById('verify-code-btn').addEventListener('click', async () => {
        const email = document.getElementById('forgot-email').value.trim();
        const code = document.getElementById('verification-code').value.trim();

        try {
            const response = await fetch('http://localhost:5000/verify-code', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, code }),
            });
            const data = await response.json();
            if (response.ok) {
                alert('Code verified. You can reset your password now.');
                verifyStep.classList.add('hidden');
                resetStep.classList.remove('hidden');
            } else {
                alert(data.error || 'Invalid verification code.');
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred.');
        }
    });

    document.getElementById('reset-password-btn').addEventListener('click', async () => {
        const email = document.getElementById('forgot-email').value.trim();
        const newPassword = document.getElementById('new-password').value.trim();
        const confirmPassword = document.getElementById('confirm-password').value.trim();

        if (newPassword !== confirmPassword) {
            alert('Passwords do not match.');
            return;
        }

        try {
            const response = await fetch('http://localhost:5000/reset-password', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password: newPassword }),
            });
            const data = await response.json();
            if (response.ok) {
                alert('Password reset successfully. Please log in.');
                resetStep.classList.add('hidden');
                forgotPasswordForm.classList.add('hidden');
                loginForm.classList.remove('hidden');
            } else {
                alert(data.error || 'Failed to reset password.');
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred.');
        }
    });
});