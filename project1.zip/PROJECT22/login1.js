document.getElementById('signup-btn').addEventListener('click', async (e) => {
    e.preventDefault();

    const firstName = document.getElementById('signup-firstName').value.trim();
    const lastName = document.getElementById('signup-lastName').value.trim();
    const email = document.getElementById('signup-email').value.trim();
    const password = document.getElementById('signup-password').value.trim();

    if (!firstName || !lastName || !email || !password) {
        alert("All fields are required.");
        return;
    }

    try {
        const response = await fetch('http://localhost:5000/signup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ firstName, lastName, email, password }),
        });

        const result = await response.json();

        if (response.ok && result.success) {
            // Ensure all required user details are present in the response
            if (result.user && result.user.firstName && result.user.email) {
                localStorage.setItem(
                    'currentUser',
                    JSON.stringify(result.user)
                );
                alert(result.message || "Signup successful!");
                window.location.href = 'index.html'; // Redirect to home/profile
            } else {
                throw new Error("Signup response is missing user details.");
            }
        } 
    } catch (error) {
        console.error("Signup error:", error);
        alert('An error occurred during signup. Please try again.');
    }
});
