// Function to open UPI app for donations
function openUPIApp() {
    const upiId = "9392406119@ybl";
    const upiUrl = `upi://pay?pa=${upiId}&pn=Your Organization&mc=0000&tid=UniqueTxn12345&tr=TxnRef12345&tn=Donate%20to%20Charity&cu=INR&am=`;

    // Redirect to UPI app
    window.location.href = upiUrl;
}

// Function to open bank transfer options in payment apps
function openBankTransfer() {
    const accountNumber = "65467897657";
    const ifscCode = "SBIN0002345";
    const bankTransferUrl = `upi://pay?pa=&pn=Your Organization&tid=UniqueTxn12345&tr=TxnRef12345&tn=Send%20via%20Bank&cu=INR&am=&orgAccNo=${accountNumber}&ifsc=${ifscCode}`;

    // Redirect to payment app for bank transfer
    window.location.href = bankTransferUrl;
}
