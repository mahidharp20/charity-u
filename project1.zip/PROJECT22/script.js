// Login functionality
document.getElementById("login-btn").addEventListener("click", (e) => {
    e.preventDefault();

    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;

    const users = JSON.parse(localStorage.getItem("users")) || [];

    const currentUser = users.find(user => user.email === email);

    if (currentUser) {
        localStorage.setItem("currentUser", JSON.stringify(currentUser)); // Save logged-in user
        alert("Login successful!");
        window.location.href = "index.html"; // Redirect to index.html
    } else {
        alert("Invalid login credentials. Please try again.");
    }
});

// Handle donation form submission
document.getElementById('donation-form').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent the page from reloading

    // Collect form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;
    const amount = document.getElementById('amount').value;
    const message = document.getElementById('message').value;

    // Validate mandatory fields
    if (!name || !email || !phone || !address || !amount) {
        alert("Please fill out all required fields.");
        return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("Please enter a valid email address.");
        return;
    }

    // Validate phone number (only numbers allowed, 10 digits)
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(phone)) {
        alert("Please enter a valid 10-digit phone number.");
        return;
    }

    // Validate donation amount (must be a number greater than 0)
    if (amount <= 0 || isNaN(amount)) {
        alert("Please enter a valid donation amount.");
        return;
    }

    const donationData = { name, email, phone, address, amount, message };

    try {
        // Send data to the server
        const response = await fetch('http://localhost:5000/donate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(donationData),
        });

        if (response.ok) {
            // On successful response, redirect to the bank details page
            alert("You Are Leaving This Page For Transaction.");
            window.location.href = 'bank.details.html';

            // Prevent back navigation to the donation page
            setTimeout(() => {
                history.pushState(null, null, window.location.href);
                window.addEventListener("popstate", function () {
                    history.pushState(null, null, window.location.href);
                });
            }, 0);
        } else {
            alert('Failed to process the donation. Please try again.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while submitting your donation.');
    }
});

// Logout functionality
function logout() {
    alert("You have been logged out.");
    localStorage.removeItem("currentUser"); // Clear session
    window.location.href = "index1.html"; // Redirect to the login page

    // Clear browsing history to prevent back navigation
    setTimeout(() => {
        history.pushState(null, null, window.location.href);
        window.addEventListener("popstate", function () {
            history.pushState(null, null, window.location.href);
        });
    }, 0);
}

// Handle Profile Modal
function showProfile() {
    const profileModal = document.getElementById('profile-modal');
    profileModal.classList.remove('hidden');

    // Populate the modal with user details (can be fetched dynamically)
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (currentUser) {
        document.getElementById('profile-first-name').textContent = currentUser.firstName;
        document.getElementById('profile-last-name').textContent = currentUser.lastName;
        document.getElementById('profile-email').textContent = currentUser.email;
    }
}

function closeProfile() {
    const profileModal = document.getElementById('profile-modal');
    profileModal.classList.add('hidden');
}
